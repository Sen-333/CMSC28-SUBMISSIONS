#include <iostream>

using namespace std;

// Function to display program description
void progdescription()
{
    cout << "============================================================================================================" << endl;
    cout << "This program finds the highest and lowest number among three input values and calculates their difference." << endl;
    cout << "Programmer: Kyle Senoy" << endl;
    cout << "[CMSC 28 WARM-UP EXERCISE]" << endl;
    cout << "============================================================================================================" << endl;
    cout << "" << endl;
}

// Function to read input values
void readdata(int &x, int &y, int &z)
{
    cout << "Enter the value of x: ";
    cin >> x;
    cout << "Enter the value of y: ";
    cin >> y;
    cout << "Enter the value of z: ";
    cin >> z;
}

// Function to determine the highest value
int largest(int x, int y, int z)
{
    int maxVal = x;
    if (y > maxVal)
        maxVal = y;
    if (z > maxVal)
        maxVal = z;
    return maxVal;
}

// Function to determine the lowest value
int smallest(int x, int y, int z)
{
    int minVal = x;
    if (y < minVal)
        minVal = y;
    if (z < minVal)
        minVal = z;
    return minVal;
}

// Function to display values
void showdata(int x, int y, int z, int largeval, int smallval, int diff)
{
    cout << "Input values:" << endl;
    cout << "x: " << x << endl;
    cout << "y: " << y << endl;
    cout << "z: " << z << endl;
    cout << "Highest value: " << largeval << endl;
    cout << "Lowest value: " << smallval << endl;
    cout << "Difference between highest and lowest value: " << diff << endl;
}

int main()
{
    // Variable declarations
    int x, y, z, largeval, smallval, diff;

    // Program description
    progdescription();

    // Read input values
    readdata(x, y, z);

    // Get highest and lowest values
    largeval = largest(x, y, z);
    smallval = smallest(x, y, z);

    // Calculate difference
    diff = largeval - smallval;

    // Display values
    showdata(x, y, z, largeval, smallval, diff);

    return 0;
}
