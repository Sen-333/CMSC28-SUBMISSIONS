#include <iostream>

using namespace std;

// Function to display program description
void progdescription()
{
    cout << "===================================================================" << endl;
    cout << "This program converts a decimal number to its binary equivalent." << endl;
    cout << "Programmer: Kyle Senoy" << endl;
    cout << "[CMSC 28 WARM-UP EXERCISE]" << endl;
    cout << "===================================================================" << endl;
    cout << "" << endl;
}

// Function to convert decimal to binary
void decimalToBinary(int num)
{
    // Array to store binary digits
    int binary[32];
    int i = 0;

    // Convert decimal to binary
    while (num > 0)
    {
        binary[i] = num % 2;
        num = num / 2;
        i++;
    }

    // Display binary equivalent
    cout << "Binary equivalent: ";
    for (int j = i - 1; j >= 0; j--)
    {
        cout << binary[j];
    }
    cout << endl;
}

int main()
{
    // Variable declaration
    int num;

    // Program description
    progdescription();

    // Input decimal number
    cout << "Enter an integer: ";
    cin >> num;

    // Convert decimal to binary
    decimalToBinary(num);

    return 0;
}
